/**
 * 
 */
/**
 * @author aleph
 *
 */
module ASSIGNMENT_1_JAVA {
}