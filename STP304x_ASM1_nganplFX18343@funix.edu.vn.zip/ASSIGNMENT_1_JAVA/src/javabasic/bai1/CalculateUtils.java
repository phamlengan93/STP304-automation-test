package javabasic.bai1;
import java.util.Scanner;

public class CalculateUtils {
	public static double tinhTong (double x, double y) {
		return (x+y);
	}
	public static double tinhNhan (double x, double y) {
		return (x*y);
	}
	public static double tinhHieu (double x, double y) {
		return (x-y);
	}
	public static double tinhChia (double x, double y) {
		return (x/y);
	}
}
